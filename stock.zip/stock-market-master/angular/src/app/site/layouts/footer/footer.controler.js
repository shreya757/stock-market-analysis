'use strict';

angular.module('app.site')
    .controller('SiteFooterController', ['$scope', function ($scope) {
        this.content = "Copyright © 2016 Stock Market"
    }]);
