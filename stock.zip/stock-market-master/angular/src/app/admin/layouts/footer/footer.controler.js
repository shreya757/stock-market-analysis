'use strict';

angular.module('app.admin')
    .controller('AdminFooterController', ['$scope', function ($scope) {
        this.content = "Copyright © 2016 Stock Market"
    }]);
